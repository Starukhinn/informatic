#include "test_runner.h"
void Test_process_military_request();
void Test_update();
void All_tests();