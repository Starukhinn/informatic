#pragma once
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

class ResultsHolder {
public:

    void update(const string& full_name, const size_t& mark);

    void print_students() const;

    void print_standings() const;

    set<string> process_military_request(const set<string>& names);

    map <string, size_t> get_base(){
        return base_students;
    }

private:
    map <string, size_t> base_students;
};