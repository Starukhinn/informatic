#include "test_runner.h"
#include "class_of_students.h"
#include "All_tests.h"

void Test_update(){
    ResultsHolder students;
    students.update("Tema", 10);
    students.update("Dima", 3);

    map <string, size_t> true_old_base {{"Tema", 10},{"Dima", 3}};

    AssertEqual(students.get_base(), true_old_base, "update test");

    students.update("Tema", 8);
    students.update("Dany", 0);

    map <string, size_t> true_base {{"Tema", 8},{"Dima", 3}, {"Dany", 0} };

    AssertEqual(students.get_base(), true_base, "update test with appeletion");
}

void Test_process_military_request(){
    ResultsHolder students;
    students.update("Tema", 8);
    students.update("Dima", 3);
    students.update("Dany", 0);
    students.update("Ann", 2);
    students.update("Lena", 1);
    students.update("Tom", 4);

    set <string> names_to_test1 {"Tema", "Dima", "Dany", "Lena", "Ann", "Tom"};
    set <string> names_to_test2 {"Tema"};
    set <string> names_to_test3 {};
    set <string> names_to_test4 {"Dany", "Lena", "Ann"};
    set <string> true_set1 {"Dany", "Lena", "Ann"};
    set <string> true_set2 {};
    set <string> true_set3 {};
    set <string> true_set4 {"Dany", "Lena", "Ann"};

    AssertEqual(students.process_military_request(names_to_test1), true_set1, "names_to_test1");
    students.update("Tema", 8);
    students.update("Dima", 3);
    students.update("Dany", 0);
    students.update("Ann", 2);
    students.update("Lena", 1);
    students.update("Tom", 4);

    AssertEqual(students.process_military_request(names_to_test2), true_set2, "names_to_test2");
    students.update("Tema", 8);
    students.update("Dima", 3);
    students.update("Dany", 0);
    students.update("Ann", 2);
    students.update("Lena", 1);
    students.update("Tom", 4);

    AssertEqual(students.process_military_request(names_to_test3), true_set3, "names_to_test3");
    students.update("Tema", 8);
    students.update("Dima", 3);
    students.update("Dany", 0);
    students.update("Ann", 2);
    students.update("Lena", 1);
    students.update("Tom", 4);

    AssertEqual(students.process_military_request(names_to_test4), true_set4, "names_to_test4");
}

void All_tests(){
    TestRunner test_runner;
    test_runner.RunTest(Test_process_military_request, "Test_process_military_request");
    test_runner.RunTest(Test_update, "Test_update");

}