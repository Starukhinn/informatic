#include "class_of_students.h"

void ResultsHolder::update(const string& full_name, const size_t& mark){
    base_students[full_name] = mark;
}

void ResultsHolder::print_students() const {
    for (auto& item_of_base: base_students){
        cout << item_of_base.first << " " << item_of_base.second << endl;
    }
}

void ResultsHolder::print_standings() const {
    vector <pair <size_t, string>> base_of_students;
    base_of_students.reserve(base_students.size());
    for (auto& item_base_students: base_students){
        base_of_students.emplace_back(item_base_students.second, item_base_students.first);
    }
    sort(begin(base_of_students), end(base_of_students), [](auto& student1, auto& student2){
        if(student1.first > student2.first){
            return student1.first > student2.first;
        }
        else if (student1.first == student2.first){
            return student1.second < student2.second;}
    });
    for (auto& item_of_student: base_of_students){
        cout << item_of_student.second << " " << item_of_student.first << endl;
    }
}

set<string> ResultsHolder::process_military_request(const set<string>& names){
    set <string> names_to_military;
    for (const auto& item_of_names: names){
        auto it = find_if (begin(base_students), end(base_students), [&item_of_names](const pair <string, size_t>& data)
        {
            return (data.first == item_of_names);
        });
        if (it->second < 3){
            names_to_military.insert(it->first);
            base_students.erase(it->first);
        }
    }
    return names_to_military;
}
