#include "class_of_students.h"
#include "All_tests.h"
int main() {
    All_tests();

    // Создали таблицу
    ResultsHolder rh;

    // Загрузили результаты
    rh.update("Alex", 6);
    rh.update("Anny", 5);
    rh.update("Ivan", 10);
    rh.update("Anastasia", 9);
    rh.update("Johnny", 1);
    rh.update("Alex", 7); // Апелляция у Alex, оценка обновляется
    rh.update("Nikita", 8);

    // Вывели в порядке убывания результата
    cout << "Exam results:" << endl;
    rh.print_standings();

    // Определили, кто идёт в армию
    auto to_military_service = rh.process_military_request({"Johnny", "Ivan"});

    // Вывели их на экран
    cout << "Are in army now:" << endl;
    for(const auto& s : to_military_service) {
        cout << s << endl;
    }

    // Вывели по алфавиту (но уже без Johnny, но Ivan остался с нами)
    cout << "Exam results:" << endl;
    rh.print_students();
}
